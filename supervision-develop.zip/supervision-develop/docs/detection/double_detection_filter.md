---
comments: true
---

# Double Detection Filter

<div class="md-typeset">
  <h2><a href="#supervision.detection.overlap_filter.OverlapFilter">OverlapFilter</a></h2>
</div>

:::supervision.detection.overlap_filter.OverlapFilter

<div class="md-typeset">
  <h2><a href="#supervision.detection.overlap_filter.box_non_max_suppression">box_non_max_suppression</a></h2>
</div>

:::supervision.detection.overlap_filter.box_non_max_suppression

<div class="md-typeset">
  <h2><a href="#supervision.detection.overlap_filter.mask_non_max_suppression">mask_non_max_suppression</a></h2>
</div>

:::supervision.detection.overlap_filter.mask_non_max_suppression

<div class="md-typeset">
  <h2><a href="#supervision.detection.overlap_filter.box_non_max_merge">box_non_max_merge</a></h2>
</div>

:::supervision.detection.overlap_filter.box_non_max_merge
