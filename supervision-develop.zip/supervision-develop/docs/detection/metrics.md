---
comments: true
---

# Metrics

<div class="md-typeset">
    <h2><a href="#supervision.metrics.detection.ConfusionMatrix">ConfusionMatrix</a></h2>
</div>

:::supervision.metrics.detection.ConfusionMatrix

<div class="md-typeset">
    <h2><a href="#supervision.metrics.detection.MeanAveragePrecision">MeanAveragePrecision</a></h2>
</div>

:::supervision.metrics.detection.MeanAveragePrecision
