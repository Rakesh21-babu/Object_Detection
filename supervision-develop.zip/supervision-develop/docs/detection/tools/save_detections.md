---
comments: true
---

# Save Detections

<div class="md-typeset">
  <h2>CSV Sink</h2>
</div>

:::supervision.detection.tools.csv_sink.CSVSink

<div class="md-typeset">
  <h2>JSON Sink</h2>
</div>

:::supervision.detection.tools.json_sink.JSONSink
