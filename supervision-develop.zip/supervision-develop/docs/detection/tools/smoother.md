---
comments: true
---

# Detection Smoother

:::supervision.detection.tools.smoother.DetectionsSmoother
