---
comments: true
---

# InferenceSlicer

:::supervision.detection.tools.inference_slicer.InferenceSlicer
