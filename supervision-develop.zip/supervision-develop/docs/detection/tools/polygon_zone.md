---
comments: true
---

<div class="md-typeset">
  <h2>PolygonZone</h2>
</div>

:::supervision.detection.tools.polygon_zone.PolygonZone

<div class="md-typeset">
  <h2>PolygonZoneAnnotator</h2>
</div>

:::supervision.detection.tools.polygon_zone.PolygonZoneAnnotator
