---
comments: true
---

<div class="md-typeset">
  <h2>LineZone</h2>
</div>

:::supervision.detection.line_zone.LineZone

<div class="md-typeset">
  <h2>LineZoneAnnotator</h2>
</div>

:::supervision.detection.line_zone.LineZoneAnnotator
