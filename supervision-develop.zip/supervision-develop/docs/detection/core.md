---
comments: true
status: new
---

# Detections

:::supervision.detection.core.Detections
