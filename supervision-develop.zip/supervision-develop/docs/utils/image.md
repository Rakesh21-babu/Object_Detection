---
comments: true
---

# Image Utils

<div class="md-typeset">
    <h2><a href="#supervision.utils.image.crop_image">crop_image</a></h2>
</div>

:::supervision.utils.image.crop_image

<div class="md-typeset">
    <h2><a href="#supervision.utils.image.scale_image">scale_image</a></h2>
</div>

:::supervision.utils.image.scale_image

<div class="md-typeset">
    <h2><a href="#supervision.utils.image.resize_image">resize_image</a></h2>
</div>

:::supervision.utils.image.resize_image

<div class="md-typeset">
    <h2><a href="#supervision.utils.image.letterbox_image">letterbox_image</a></h2>
</div>

:::supervision.utils.image.letterbox_image

<div class="md-typeset">
    <h2><a href="#supervision.utils.image.overlay_image">overlay_image</a></h2>
</div>

:::supervision.utils.image.overlay_image

<div class="md-typeset">
    <h2><a href="#supervision.utils.image.ImageSink">ImageSink</a></h2>
</div>

:::supervision.utils.image.ImageSink
