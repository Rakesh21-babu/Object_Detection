---
comments: true
---

# Iterables Utils

<div class="md-typeset">
    <h2><a href="#supervision.utils.iterables.create_batches">create_batches</a></h2>
</div>

:::supervision.utils.iterables.create_batches

<div class="md-typeset">
    <h2><a href="#supervision.utils.iterables.fill">fill</a></h2>
</div>

:::supervision.utils.iterables.fill
