---
comments: true
status: new
---

# File Utils

<div class="md-typeset">
    <h2><a href="#supervision.utils.file.list_files_with_extensions">list_files_with_extensions</a></h2>
</div>

:::supervision.utils.file.list_files_with_extensions
