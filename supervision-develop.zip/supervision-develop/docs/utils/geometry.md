---
comments: true
---

<div class="md-typeset">
    <h2><a href="#supervision.geometry.core.utils.get_polygon_center">get_polygon_center</a></h2>
</div>

:::supervision.geometry.utils.get_polygon_center

<div class="md-typeset">
    <h2><a href="#supervision.geometry.core.Position">Position</a></h2>
</div>

:::supervision.geometry.core.Position
