---
comments: true
---

# Video Utils

<div class="md-typeset">
    <h2><a href="#supervision.utils.video.VideoInfo">VideoInfo</a></h2>
</div>

:::supervision.utils.video.VideoInfo

<div class="md-typeset">
    <h2><a href="#supervision.utils.video.VideoSink">VideoSink</a></h2>
</div>

:::supervision.utils.video.VideoSink

<div class="md-typeset">
    <h2><a href="#supervision.utils.video.FPSMonitor">FPSMonitor</a></h2>
</div>

:::supervision.utils.video.FPSMonitor

<div class="md-typeset">
    <h2><a href="#supervision.utils.video.get_video_frames_generator">get_video_frames_generator</a></h2>
</div>

:::supervision.utils.video.get_video_frames_generator

<div class="md-typeset">
    <h2><a href="#supervision.utils.video.process_video">process_video</a></h2>
</div>

:::supervision.utils.video.process_video
