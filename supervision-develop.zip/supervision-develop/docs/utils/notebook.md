---
comments: true
---

# Notebooks Utils

<div class="md-typeset">
    <h2><a href="#supervision.utils.notebook.plot_image">plot_image</a></h2>
</div>

:::supervision.utils.notebook.plot_image

<div class="md-typeset">
    <h2><a href="#supervision.utils.notebook.plot_images_grid">plot_images_grid</a></h2>
</div>

:::supervision.utils.notebook.plot_images_grid
