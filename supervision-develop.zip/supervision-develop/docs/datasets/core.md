---
comments: true
status: new
---

# Datasets

!!! warning

    Dataset API is still fluid and may change. If you use Dataset API in your project until further notice, freeze the
    `supervision` version in your `requirements.txt` or `setup.py`.

<div class="md-typeset">
  <h2>DetectionDataset</h2>
</div>

:::supervision.dataset.core.DetectionDataset

<div class="md-typeset">
  <h2>ClassificationDataset</h2>
</div>

:::supervision.dataset.core.ClassificationDataset
