---
comments: true
---

# Datasets Utils

<div class="md-typeset">
  <h2><a href="#supervision.dataset.utils.rle_to_mask">rle_to_mask</a></h2>
</div>

:::supervision.dataset.utils.rle_to_mask

<div class="md-typeset">
  <h2><a href="#supervision.dataset.utils.mask_to_rle">mask_to_rle</a></h2>
</div>

:::supervision.dataset.utils.mask_to_rle
