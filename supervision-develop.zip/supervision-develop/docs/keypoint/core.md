---
comments: true
status: new
---

# Keypoint Detection

:::supervision.keypoint.core.KeyPoints
