---
comments: true
---

# ByteTrack

:::supervision.tracker.byte_tracker.core.ByteTrack
